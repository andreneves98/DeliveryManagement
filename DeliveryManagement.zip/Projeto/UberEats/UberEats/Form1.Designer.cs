﻿using System.Drawing;
namespace UberEats
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.painel_editencomenda = new System.Windows.Forms.Panel();
            this.radioButton4 = new System.Windows.Forms.RadioButton();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.label15 = new System.Windows.Forms.Label();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.checkedListBox2 = new System.Windows.Forms.CheckedListBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label50 = new System.Windows.Forms.Label();
            this.b_ok_editencomenda = new System.Windows.Forms.Button();
            this.b_cancel_edit_encomenda = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.painel_clientes = new System.Windows.Forms.Panel();
            this.tabela_clientes = new System.Windows.Forms.DataGridView();
            this.label39 = new System.Windows.Forms.Label();
            this.b_elim_cliente = new System.Windows.Forms.Button();
            this.b_edit_cliente = new System.Windows.Forms.Button();
            this.b_add_cliente = new System.Windows.Forms.Button();
            this.painel_edit_cliente = new System.Windows.Forms.Panel();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label49 = new System.Windows.Forms.Label();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.label53 = new System.Windows.Forms.Label();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.label55 = new System.Windows.Forms.Label();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.b_ok_edit_cliente = new System.Windows.Forms.Button();
            this.b_cancel_edit_cliente = new System.Windows.Forms.Button();
            this.label57 = new System.Windows.Forms.Label();
            this.painel_add_cliente = new System.Windows.Forms.Panel();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.label40 = new System.Windows.Forms.Label();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.b_ok_add_cliente = new System.Windows.Forms.Button();
            this.b_cancel_add_cliente = new System.Windows.Forms.Button();
            this.label48 = new System.Windows.Forms.Label();
            this.painel_motoristas = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.b_elim_motorista = new System.Windows.Forms.Button();
            this.b_edit_motorista = new System.Windows.Forms.Button();
            this.b_add_motorista = new System.Windows.Forms.Button();
            this.tabela_motoristas = new System.Windows.Forms.DataGridView();
            this.painel_edit_motorista = new System.Windows.Forms.Panel();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.b_ok_edit_motorista = new System.Windows.Forms.Button();
            this.b_cancel_edit_motorista = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.painel_addmotorista = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.b_ok_add_motorista = new System.Windows.Forms.Button();
            this.b_cancel_add_motorista = new System.Windows.Forms.Button();
            this.label26 = new System.Windows.Forms.Label();
            this.painel_addencomenda = new System.Windows.Forms.Panel();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.label30 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.b_ok_addencomenda = new System.Windows.Forms.Button();
            this.b_cancel_add_encomenda = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.checkedListBox1 = new System.Windows.Forms.CheckedListBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.painel_encomendas = new System.Windows.Forms.Panel();
            this.tabela_encomendas = new System.Windows.Forms.DataGridView();
            this.label19 = new System.Windows.Forms.Label();
            this.elim_encomenda = new System.Windows.Forms.Button();
            this.b_edit_encomenda = new System.Windows.Forms.Button();
            this.b_add_encomenda = new System.Windows.Forms.Button();
            this.exit_button = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.b_lateral_clientes = new System.Windows.Forms.Button();
            this.b_motoristas_lateral = new System.Windows.Forms.Button();
            this.b_encomendas_lateral = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.Nr_Reg = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.MarcaVeiculo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Matricula = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.radioButton5 = new System.Windows.Forms.RadioButton();
            this.panel1.SuspendLayout();
            this.painel_editencomenda.SuspendLayout();
            this.painel_clientes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabela_clientes)).BeginInit();
            this.painel_edit_cliente.SuspendLayout();
            this.painel_add_cliente.SuspendLayout();
            this.painel_motoristas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabela_motoristas)).BeginInit();
            this.painel_edit_motorista.SuspendLayout();
            this.painel_addmotorista.SuspendLayout();
            this.painel_addencomenda.SuspendLayout();
            this.painel_encomendas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabela_encomendas)).BeginInit();
            this.panel5.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(0, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(93, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "UBER";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 20F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(204)))), ((int)(((byte)(0)))));
            this.label2.Location = new System.Drawing.Point(87, 11);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(86, 32);
            this.label2.TabIndex = 1;
            this.label2.Text = "EATS";
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.painel_editencomenda);
            this.panel1.Controls.Add(this.painel_clientes);
            this.panel1.Controls.Add(this.painel_edit_cliente);
            this.panel1.Controls.Add(this.painel_add_cliente);
            this.panel1.Controls.Add(this.painel_motoristas);
            this.panel1.Controls.Add(this.painel_edit_motorista);
            this.panel1.Controls.Add(this.painel_addmotorista);
            this.panel1.Controls.Add(this.painel_addencomenda);
            this.panel1.Controls.Add(this.painel_encomendas);
            this.panel1.Controls.Add(this.exit_button);
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.b_lateral_clientes);
            this.panel1.Controls.Add(this.b_motoristas_lateral);
            this.panel1.Controls.Add(this.b_encomendas_lateral);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Location = new System.Drawing.Point(12, 71);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(776, 428);
            this.panel1.TabIndex = 2;
            // 
            // painel_editencomenda
            // 
            this.painel_editencomenda.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_editencomenda.Controls.Add(this.radioButton5);
            this.painel_editencomenda.Controls.Add(this.radioButton4);
            this.painel_editencomenda.Controls.Add(this.radioButton3);
            this.painel_editencomenda.Controls.Add(this.label15);
            this.painel_editencomenda.Controls.Add(this.textBox26);
            this.painel_editencomenda.Controls.Add(this.textBox25);
            this.painel_editencomenda.Controls.Add(this.label13);
            this.painel_editencomenda.Controls.Add(this.textBox2);
            this.painel_editencomenda.Controls.Add(this.label14);
            this.painel_editencomenda.Controls.Add(this.checkedListBox2);
            this.painel_editencomenda.Controls.Add(this.label17);
            this.painel_editencomenda.Controls.Add(this.label50);
            this.painel_editencomenda.Controls.Add(this.b_ok_editencomenda);
            this.painel_editencomenda.Controls.Add(this.b_cancel_edit_encomenda);
            this.painel_editencomenda.Controls.Add(this.label18);
            this.painel_editencomenda.Location = new System.Drawing.Point(184, 20);
            this.painel_editencomenda.Name = "painel_editencomenda";
            this.painel_editencomenda.Size = new System.Drawing.Size(567, 399);
            this.painel_editencomenda.TabIndex = 13;
            this.painel_editencomenda.Visible = false;
            // 
            // radioButton4
            // 
            this.radioButton4.AutoSize = true;
            this.radioButton4.Location = new System.Drawing.Point(325, 284);
            this.radioButton4.Name = "radioButton4";
            this.radioButton4.Size = new System.Drawing.Size(67, 17);
            this.radioButton4.TabIndex = 44;
            this.radioButton4.TabStop = true;
            this.radioButton4.Text = "Cancelar";
            this.radioButton4.UseVisualStyleBackColor = true;
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.Location = new System.Drawing.Point(235, 284);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(66, 17);
            this.radioButton3.TabIndex = 43;
            this.radioButton3.TabStop = true;
            this.radioButton3.Text = "Terminar";
            this.radioButton3.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 10F);
            this.label15.Location = new System.Drawing.Point(60, 285);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(52, 16);
            this.label15.TabIndex = 42;
            this.label15.Text = "Status:";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(148, 245);
            this.textBox26.Name = "textBox26";
            this.textBox26.ReadOnly = true;
            this.textBox26.Size = new System.Drawing.Size(93, 20);
            this.textBox26.TabIndex = 41;
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(147, 54);
            this.textBox25.Name = "textBox25";
            this.textBox25.ReadOnly = true;
            this.textBox25.Size = new System.Drawing.Size(282, 20);
            this.textBox25.TabIndex = 40;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 10F);
            this.label13.Location = new System.Drawing.Point(55, 250);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 16);
            this.label13.TabIndex = 36;
            this.label13.Text = "Método:";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(147, 206);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(282, 20);
            this.textBox2.TabIndex = 35;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 10F);
            this.label14.Location = new System.Drawing.Point(55, 207);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(38, 16);
            this.label14.TabIndex = 34;
            this.label14.Text = "Obs:";
            // 
            // checkedListBox2
            // 
            this.checkedListBox2.FormattingEnabled = true;
            this.checkedListBox2.Location = new System.Drawing.Point(147, 92);
            this.checkedListBox2.Name = "checkedListBox2";
            this.checkedListBox2.Size = new System.Drawing.Size(201, 94);
            this.checkedListBox2.TabIndex = 30;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 10F);
            this.label17.Location = new System.Drawing.Point(24, 96);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(69, 16);
            this.label17.TabIndex = 29;
            this.label17.Text = "Produtos:";
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Arial", 10F);
            this.label50.Location = new System.Drawing.Point(24, 60);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(56, 16);
            this.label50.TabIndex = 25;
            this.label50.Text = "Cliente:";
            // 
            // b_ok_editencomenda
            // 
            this.b_ok_editencomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.b_ok_editencomenda.Location = new System.Drawing.Point(325, 335);
            this.b_ok_editencomenda.Name = "b_ok_editencomenda";
            this.b_ok_editencomenda.Size = new System.Drawing.Size(140, 51);
            this.b_ok_editencomenda.TabIndex = 24;
            this.b_ok_editencomenda.Text = "OK";
            this.b_ok_editencomenda.UseVisualStyleBackColor = true;
            this.b_ok_editencomenda.Click += new System.EventHandler(this.b_ok_editencomenda_Click);
            // 
            // b_cancel_edit_encomenda
            // 
            this.b_cancel_edit_encomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.b_cancel_edit_encomenda.Location = new System.Drawing.Point(101, 335);
            this.b_cancel_edit_encomenda.Name = "b_cancel_edit_encomenda";
            this.b_cancel_edit_encomenda.Size = new System.Drawing.Size(140, 51);
            this.b_cancel_edit_encomenda.TabIndex = 23;
            this.b_cancel_edit_encomenda.Text = "Cancelar";
            this.b_cancel_edit_encomenda.UseVisualStyleBackColor = true;
            this.b_cancel_edit_encomenda.Click += new System.EventHandler(this.b_cancel_edit_encomenda_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label18.Location = new System.Drawing.Point(23, 14);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(181, 22);
            this.label18.TabIndex = 13;
            this.label18.Text = "Editar Encomenda";
            // 
            // painel_clientes
            // 
            this.painel_clientes.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_clientes.Controls.Add(this.tabela_clientes);
            this.painel_clientes.Controls.Add(this.label39);
            this.painel_clientes.Controls.Add(this.b_elim_cliente);
            this.painel_clientes.Controls.Add(this.b_edit_cliente);
            this.painel_clientes.Controls.Add(this.b_add_cliente);
            this.painel_clientes.Location = new System.Drawing.Point(184, 20);
            this.painel_clientes.Name = "painel_clientes";
            this.painel_clientes.Size = new System.Drawing.Size(567, 399);
            this.painel_clientes.TabIndex = 29;
            this.painel_clientes.Visible = false;
            // 
            // tabela_clientes
            // 
            this.tabela_clientes.AllowUserToAddRows = false;
            this.tabela_clientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabela_clientes.Location = new System.Drawing.Point(0, 26);
            this.tabela_clientes.Name = "tabela_clientes";
            this.tabela_clientes.ReadOnly = true;
            this.tabela_clientes.RowHeadersVisible = false;
            this.tabela_clientes.Size = new System.Drawing.Size(567, 313);
            this.tabela_clientes.TabIndex = 0;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label39.Location = new System.Drawing.Point(3, 0);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(85, 22);
            this.label39.TabIndex = 4;
            this.label39.Text = "Clientes";
            // 
            // b_elim_cliente
            // 
            this.b_elim_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_elim_cliente.Location = new System.Drawing.Point(392, 345);
            this.b_elim_cliente.Name = "b_elim_cliente";
            this.b_elim_cliente.Size = new System.Drawing.Size(136, 51);
            this.b_elim_cliente.TabIndex = 3;
            this.b_elim_cliente.Text = "Eliminar";
            this.b_elim_cliente.UseVisualStyleBackColor = true;
            this.b_elim_cliente.Click += new System.EventHandler(this.b_elim_cliente_Click);
            // 
            // b_edit_cliente
            // 
            this.b_edit_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_edit_cliente.Location = new System.Drawing.Point(218, 345);
            this.b_edit_cliente.Name = "b_edit_cliente";
            this.b_edit_cliente.Size = new System.Drawing.Size(136, 51);
            this.b_edit_cliente.TabIndex = 2;
            this.b_edit_cliente.Text = "Editar";
            this.b_edit_cliente.UseVisualStyleBackColor = true;
            this.b_edit_cliente.Click += new System.EventHandler(this.b_edit_cliente_Click);
            // 
            // b_add_cliente
            // 
            this.b_add_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_add_cliente.Location = new System.Drawing.Point(43, 345);
            this.b_add_cliente.Name = "b_add_cliente";
            this.b_add_cliente.Size = new System.Drawing.Size(136, 51);
            this.b_add_cliente.TabIndex = 1;
            this.b_add_cliente.Text = "Adicionar";
            this.b_add_cliente.UseVisualStyleBackColor = true;
            this.b_add_cliente.Click += new System.EventHandler(this.b_add_cliente_Click);
            // 
            // painel_edit_cliente
            // 
            this.painel_edit_cliente.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_edit_cliente.Controls.Add(this.textBox24);
            this.painel_edit_cliente.Controls.Add(this.label49);
            this.painel_edit_cliente.Controls.Add(this.textBox27);
            this.painel_edit_cliente.Controls.Add(this.label53);
            this.painel_edit_cliente.Controls.Add(this.textBox28);
            this.painel_edit_cliente.Controls.Add(this.label54);
            this.painel_edit_cliente.Controls.Add(this.textBox29);
            this.painel_edit_cliente.Controls.Add(this.label55);
            this.painel_edit_cliente.Controls.Add(this.textBox30);
            this.painel_edit_cliente.Controls.Add(this.label56);
            this.painel_edit_cliente.Controls.Add(this.b_ok_edit_cliente);
            this.painel_edit_cliente.Controls.Add(this.b_cancel_edit_cliente);
            this.painel_edit_cliente.Controls.Add(this.label57);
            this.painel_edit_cliente.Location = new System.Drawing.Point(184, 20);
            this.painel_edit_cliente.Name = "painel_edit_cliente";
            this.painel_edit_cliente.Size = new System.Drawing.Size(567, 399);
            this.painel_edit_cliente.TabIndex = 30;
            this.painel_edit_cliente.Visible = false;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(104, 222);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(346, 20);
            this.textBox24.TabIndex = 22;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Arial", 10F);
            this.label49.Location = new System.Drawing.Point(40, 223);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(60, 16);
            this.label49.TabIndex = 21;
            this.label49.Text = "Morada:";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(104, 144);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(129, 20);
            this.textBox27.TabIndex = 20;
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Arial", 10F);
            this.label53.Location = new System.Drawing.Point(23, 145);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(75, 16);
            this.label53.TabIndex = 19;
            this.label53.Text = "Telemóvel:";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(103, 107);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(347, 20);
            this.textBox28.TabIndex = 18;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Arial", 10F);
            this.label54.Location = new System.Drawing.Point(46, 108);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(46, 16);
            this.label54.TabIndex = 17;
            this.label54.Text = "Email:";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(104, 183);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(129, 20);
            this.textBox29.TabIndex = 16;
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Arial", 10F);
            this.label55.Location = new System.Drawing.Point(55, 184);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(33, 16);
            this.label55.TabIndex = 15;
            this.label55.Text = "NIF:";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(103, 69);
            this.textBox30.Name = "textBox30";
            this.textBox30.ReadOnly = true;
            this.textBox30.Size = new System.Drawing.Size(347, 20);
            this.textBox30.TabIndex = 14;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Arial", 10F);
            this.label56.Location = new System.Drawing.Point(43, 70);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(48, 16);
            this.label56.TabIndex = 13;
            this.label56.Text = "Nome:";
            // 
            // b_ok_edit_cliente
            // 
            this.b_ok_edit_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_ok_edit_cliente.Location = new System.Drawing.Point(311, 335);
            this.b_ok_edit_cliente.Name = "b_ok_edit_cliente";
            this.b_ok_edit_cliente.Size = new System.Drawing.Size(140, 51);
            this.b_ok_edit_cliente.TabIndex = 12;
            this.b_ok_edit_cliente.Text = "OK";
            this.b_ok_edit_cliente.UseVisualStyleBackColor = true;
            this.b_ok_edit_cliente.Click += new System.EventHandler(this.b_ok_edit_cliente_Click);
            // 
            // b_cancel_edit_cliente
            // 
            this.b_cancel_edit_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_cancel_edit_cliente.Location = new System.Drawing.Point(87, 335);
            this.b_cancel_edit_cliente.Name = "b_cancel_edit_cliente";
            this.b_cancel_edit_cliente.Size = new System.Drawing.Size(140, 51);
            this.b_cancel_edit_cliente.TabIndex = 11;
            this.b_cancel_edit_cliente.Text = "Cancelar";
            this.b_cancel_edit_cliente.UseVisualStyleBackColor = true;
            this.b_cancel_edit_cliente.Click += new System.EventHandler(this.b_cancel_edit_cliente_Click);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label57.Location = new System.Drawing.Point(15, 7);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(134, 22);
            this.label57.TabIndex = 0;
            this.label57.Text = "Editar Cliente";
            // 
            // painel_add_cliente
            // 
            this.painel_add_cliente.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_add_cliente.Controls.Add(this.textBox17);
            this.painel_add_cliente.Controls.Add(this.label40);
            this.painel_add_cliente.Controls.Add(this.textBox18);
            this.painel_add_cliente.Controls.Add(this.label41);
            this.painel_add_cliente.Controls.Add(this.textBox20);
            this.painel_add_cliente.Controls.Add(this.label44);
            this.painel_add_cliente.Controls.Add(this.textBox21);
            this.painel_add_cliente.Controls.Add(this.label45);
            this.painel_add_cliente.Controls.Add(this.textBox22);
            this.painel_add_cliente.Controls.Add(this.label46);
            this.painel_add_cliente.Controls.Add(this.b_ok_add_cliente);
            this.painel_add_cliente.Controls.Add(this.b_cancel_add_cliente);
            this.painel_add_cliente.Controls.Add(this.label48);
            this.painel_add_cliente.Location = new System.Drawing.Point(184, 20);
            this.painel_add_cliente.Name = "painel_add_cliente";
            this.painel_add_cliente.Size = new System.Drawing.Size(567, 399);
            this.painel_add_cliente.TabIndex = 14;
            this.painel_add_cliente.Visible = false;
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(102, 225);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(346, 20);
            this.textBox17.TabIndex = 32;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 10F);
            this.label40.Location = new System.Drawing.Point(38, 226);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(60, 16);
            this.label40.TabIndex = 31;
            this.label40.Text = "Morada:";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(102, 147);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(129, 20);
            this.textBox18.TabIndex = 30;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 10F);
            this.label41.Location = new System.Drawing.Point(21, 148);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(75, 16);
            this.label41.TabIndex = 29;
            this.label41.Text = "Telemóvel:";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(101, 110);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(347, 20);
            this.textBox20.TabIndex = 28;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Arial", 10F);
            this.label44.Location = new System.Drawing.Point(44, 111);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(46, 16);
            this.label44.TabIndex = 27;
            this.label44.Text = "Email:";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(102, 186);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(129, 20);
            this.textBox21.TabIndex = 26;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Arial", 10F);
            this.label45.Location = new System.Drawing.Point(53, 187);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(33, 16);
            this.label45.TabIndex = 25;
            this.label45.Text = "NIF:";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(101, 72);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(347, 20);
            this.textBox22.TabIndex = 24;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Arial", 10F);
            this.label46.Location = new System.Drawing.Point(41, 73);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(48, 16);
            this.label46.TabIndex = 23;
            this.label46.Text = "Nome:";
            // 
            // b_ok_add_cliente
            // 
            this.b_ok_add_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_ok_add_cliente.Location = new System.Drawing.Point(311, 335);
            this.b_ok_add_cliente.Name = "b_ok_add_cliente";
            this.b_ok_add_cliente.Size = new System.Drawing.Size(140, 51);
            this.b_ok_add_cliente.TabIndex = 12;
            this.b_ok_add_cliente.Text = "OK";
            this.b_ok_add_cliente.UseVisualStyleBackColor = true;
            this.b_ok_add_cliente.Click += new System.EventHandler(this.b_ok_add_cliente_Click);
            // 
            // b_cancel_add_cliente
            // 
            this.b_cancel_add_cliente.Font = new System.Drawing.Font("Arial", 13F);
            this.b_cancel_add_cliente.Location = new System.Drawing.Point(87, 335);
            this.b_cancel_add_cliente.Name = "b_cancel_add_cliente";
            this.b_cancel_add_cliente.Size = new System.Drawing.Size(140, 51);
            this.b_cancel_add_cliente.TabIndex = 11;
            this.b_cancel_add_cliente.Text = "Cancelar";
            this.b_cancel_add_cliente.UseVisualStyleBackColor = true;
            this.b_cancel_add_cliente.Click += new System.EventHandler(this.b_cancel_add_cliente_Click);
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label48.Location = new System.Drawing.Point(15, 7);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(127, 22);
            this.label48.TabIndex = 0;
            this.label48.Text = "Novo Cliente";
            // 
            // painel_motoristas
            // 
            this.painel_motoristas.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_motoristas.Controls.Add(this.label20);
            this.painel_motoristas.Controls.Add(this.b_elim_motorista);
            this.painel_motoristas.Controls.Add(this.b_edit_motorista);
            this.painel_motoristas.Controls.Add(this.b_add_motorista);
            this.painel_motoristas.Controls.Add(this.tabela_motoristas);
            this.painel_motoristas.Location = new System.Drawing.Point(184, 20);
            this.painel_motoristas.Name = "painel_motoristas";
            this.painel_motoristas.Size = new System.Drawing.Size(567, 399);
            this.painel_motoristas.TabIndex = 14;
            this.painel_motoristas.Visible = false;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label20.Location = new System.Drawing.Point(3, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(109, 22);
            this.label20.TabIndex = 4;
            this.label20.Text = "Motoristas";
            // 
            // b_elim_motorista
            // 
            this.b_elim_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_elim_motorista.Location = new System.Drawing.Point(392, 345);
            this.b_elim_motorista.Name = "b_elim_motorista";
            this.b_elim_motorista.Size = new System.Drawing.Size(136, 51);
            this.b_elim_motorista.TabIndex = 3;
            this.b_elim_motorista.Text = "Eliminar";
            this.b_elim_motorista.UseVisualStyleBackColor = true;
            this.b_elim_motorista.Click += new System.EventHandler(this.b_elim_motorista_Click);
            // 
            // b_edit_motorista
            // 
            this.b_edit_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_edit_motorista.Location = new System.Drawing.Point(218, 345);
            this.b_edit_motorista.Name = "b_edit_motorista";
            this.b_edit_motorista.Size = new System.Drawing.Size(136, 51);
            this.b_edit_motorista.TabIndex = 2;
            this.b_edit_motorista.Text = "Editar";
            this.b_edit_motorista.UseVisualStyleBackColor = true;
            this.b_edit_motorista.Click += new System.EventHandler(this.b_edit_motorista_Click);
            // 
            // b_add_motorista
            // 
            this.b_add_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_add_motorista.Location = new System.Drawing.Point(43, 345);
            this.b_add_motorista.Name = "b_add_motorista";
            this.b_add_motorista.Size = new System.Drawing.Size(136, 51);
            this.b_add_motorista.TabIndex = 1;
            this.b_add_motorista.Text = "Adicionar";
            this.b_add_motorista.UseVisualStyleBackColor = true;
            this.b_add_motorista.Click += new System.EventHandler(this.b_add_motorista_Click);
            // 
            // tabela_motoristas
            // 
            this.tabela_motoristas.AllowUserToAddRows = false;
            this.tabela_motoristas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabela_motoristas.Location = new System.Drawing.Point(0, 26);
            this.tabela_motoristas.Name = "tabela_motoristas";
            this.tabela_motoristas.ReadOnly = true;
            this.tabela_motoristas.RowHeadersVisible = false;
            this.tabela_motoristas.Size = new System.Drawing.Size(567, 313);
            this.tabela_motoristas.TabIndex = 0;
            // 
            // painel_edit_motorista
            // 
            this.painel_edit_motorista.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_edit_motorista.Controls.Add(this.textBox11);
            this.painel_edit_motorista.Controls.Add(this.label31);
            this.painel_edit_motorista.Controls.Add(this.textBox12);
            this.painel_edit_motorista.Controls.Add(this.label32);
            this.painel_edit_motorista.Controls.Add(this.comboBox6);
            this.painel_edit_motorista.Controls.Add(this.label33);
            this.painel_edit_motorista.Controls.Add(this.textBox13);
            this.painel_edit_motorista.Controls.Add(this.label34);
            this.painel_edit_motorista.Controls.Add(this.textBox14);
            this.painel_edit_motorista.Controls.Add(this.label35);
            this.painel_edit_motorista.Controls.Add(this.textBox15);
            this.painel_edit_motorista.Controls.Add(this.label36);
            this.painel_edit_motorista.Controls.Add(this.textBox16);
            this.painel_edit_motorista.Controls.Add(this.label37);
            this.painel_edit_motorista.Controls.Add(this.b_ok_edit_motorista);
            this.painel_edit_motorista.Controls.Add(this.b_cancel_edit_motorista);
            this.painel_edit_motorista.Controls.Add(this.label38);
            this.painel_edit_motorista.Location = new System.Drawing.Point(184, 20);
            this.painel_edit_motorista.Name = "painel_edit_motorista";
            this.painel_edit_motorista.Size = new System.Drawing.Size(567, 399);
            this.painel_edit_motorista.TabIndex = 29;
            this.painel_edit_motorista.Visible = false;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(78, 150);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(342, 20);
            this.textBox11.TabIndex = 26;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 10F);
            this.label31.Location = new System.Drawing.Point(12, 154);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(60, 16);
            this.label31.TabIndex = 25;
            this.label31.Text = "Morada:";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(78, 190);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 24;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 10F);
            this.label32.Location = new System.Drawing.Point(8, 193);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(70, 16);
            this.label32.TabIndex = 23;
            this.label32.Text = "Matrícula:";
            // 
            // comboBox6
            // 
            this.comboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Location = new System.Drawing.Point(350, 187);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(186, 21);
            this.comboBox6.TabIndex = 22;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 10F);
            this.label33.Location = new System.Drawing.Point(223, 190);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(121, 16);
            this.label33.TabIndex = 21;
            this.label33.Text = "Marca do Veículo:";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(436, 106);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(100, 20);
            this.textBox13.TabIndex = 20;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 10F);
            this.label34.Location = new System.Drawing.Point(355, 110);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(75, 16);
            this.label34.TabIndex = 19;
            this.label34.Text = "Telemóvel:";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(78, 107);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(249, 20);
            this.textBox14.TabIndex = 18;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 10F);
            this.label35.Location = new System.Drawing.Point(23, 110);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(46, 16);
            this.label35.TabIndex = 17;
            this.label35.Text = "Email:";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(436, 68);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 16;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial", 10F);
            this.label36.Location = new System.Drawing.Point(397, 70);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(33, 16);
            this.label36.TabIndex = 15;
            this.label36.Text = "NIF:";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(78, 70);
            this.textBox16.Name = "textBox16";
            this.textBox16.ReadOnly = true;
            this.textBox16.Size = new System.Drawing.Size(249, 20);
            this.textBox16.TabIndex = 14;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 10F);
            this.label37.Location = new System.Drawing.Point(20, 72);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(48, 16);
            this.label37.TabIndex = 13;
            this.label37.Text = "Nome:";
            // 
            // b_ok_edit_motorista
            // 
            this.b_ok_edit_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_ok_edit_motorista.Location = new System.Drawing.Point(311, 335);
            this.b_ok_edit_motorista.Name = "b_ok_edit_motorista";
            this.b_ok_edit_motorista.Size = new System.Drawing.Size(140, 51);
            this.b_ok_edit_motorista.TabIndex = 12;
            this.b_ok_edit_motorista.Text = "OK";
            this.b_ok_edit_motorista.UseVisualStyleBackColor = true;
            this.b_ok_edit_motorista.Click += new System.EventHandler(this.b_ok_edit_motorista_Click);
            // 
            // b_cancel_edit_motorista
            // 
            this.b_cancel_edit_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_cancel_edit_motorista.Location = new System.Drawing.Point(87, 335);
            this.b_cancel_edit_motorista.Name = "b_cancel_edit_motorista";
            this.b_cancel_edit_motorista.Size = new System.Drawing.Size(140, 51);
            this.b_cancel_edit_motorista.TabIndex = 11;
            this.b_cancel_edit_motorista.Text = "Cancelar";
            this.b_cancel_edit_motorista.UseVisualStyleBackColor = true;
            this.b_cancel_edit_motorista.Click += new System.EventHandler(this.b_cancel_edit_motorista_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label38.Location = new System.Drawing.Point(15, 7);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(158, 22);
            this.label38.TabIndex = 0;
            this.label38.Text = "Editar Motorista";
            // 
            // painel_addmotorista
            // 
            this.painel_addmotorista.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_addmotorista.Controls.Add(this.textBox3);
            this.painel_addmotorista.Controls.Add(this.label21);
            this.painel_addmotorista.Controls.Add(this.textBox4);
            this.painel_addmotorista.Controls.Add(this.label22);
            this.painel_addmotorista.Controls.Add(this.comboBox5);
            this.painel_addmotorista.Controls.Add(this.label23);
            this.painel_addmotorista.Controls.Add(this.textBox5);
            this.painel_addmotorista.Controls.Add(this.label24);
            this.painel_addmotorista.Controls.Add(this.textBox6);
            this.painel_addmotorista.Controls.Add(this.label25);
            this.painel_addmotorista.Controls.Add(this.textBox7);
            this.painel_addmotorista.Controls.Add(this.label27);
            this.painel_addmotorista.Controls.Add(this.textBox8);
            this.painel_addmotorista.Controls.Add(this.label28);
            this.painel_addmotorista.Controls.Add(this.b_ok_add_motorista);
            this.painel_addmotorista.Controls.Add(this.b_cancel_add_motorista);
            this.painel_addmotorista.Controls.Add(this.label26);
            this.painel_addmotorista.Location = new System.Drawing.Point(184, 20);
            this.painel_addmotorista.Name = "painel_addmotorista";
            this.painel_addmotorista.Size = new System.Drawing.Size(567, 399);
            this.painel_addmotorista.TabIndex = 13;
            this.painel_addmotorista.Visible = false;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(77, 154);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(342, 20);
            this.textBox3.TabIndex = 40;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 10F);
            this.label21.Location = new System.Drawing.Point(11, 158);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(60, 16);
            this.label21.TabIndex = 39;
            this.label21.Text = "Morada:";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(77, 194);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 20);
            this.textBox4.TabIndex = 38;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 10F);
            this.label22.Location = new System.Drawing.Point(7, 197);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 16);
            this.label22.TabIndex = 37;
            this.label22.Text = "Matrícula:";
            // 
            // comboBox5
            // 
            this.comboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(349, 191);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(186, 21);
            this.comboBox5.TabIndex = 36;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 10F);
            this.label23.Location = new System.Drawing.Point(222, 194);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(121, 16);
            this.label23.TabIndex = 35;
            this.label23.Text = "Marca do Veículo:";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(435, 110);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 34;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 10F);
            this.label24.Location = new System.Drawing.Point(354, 114);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(75, 16);
            this.label24.TabIndex = 33;
            this.label24.Text = "Telemóvel:";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(77, 111);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(249, 20);
            this.textBox6.TabIndex = 32;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 10F);
            this.label25.Location = new System.Drawing.Point(22, 114);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(46, 16);
            this.label25.TabIndex = 31;
            this.label25.Text = "Email:";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(435, 72);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 30;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 10F);
            this.label27.Location = new System.Drawing.Point(396, 74);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(33, 16);
            this.label27.TabIndex = 29;
            this.label27.Text = "NIF:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(77, 74);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(249, 20);
            this.textBox8.TabIndex = 28;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 10F);
            this.label28.Location = new System.Drawing.Point(19, 76);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(48, 16);
            this.label28.TabIndex = 27;
            this.label28.Text = "Nome:";
            // 
            // b_ok_add_motorista
            // 
            this.b_ok_add_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_ok_add_motorista.Location = new System.Drawing.Point(311, 335);
            this.b_ok_add_motorista.Name = "b_ok_add_motorista";
            this.b_ok_add_motorista.Size = new System.Drawing.Size(140, 51);
            this.b_ok_add_motorista.TabIndex = 12;
            this.b_ok_add_motorista.Text = "OK";
            this.b_ok_add_motorista.UseVisualStyleBackColor = true;
            this.b_ok_add_motorista.Click += new System.EventHandler(this.b_ok_add_motorista_Click);
            // 
            // b_cancel_add_motorista
            // 
            this.b_cancel_add_motorista.Font = new System.Drawing.Font("Arial", 13F);
            this.b_cancel_add_motorista.Location = new System.Drawing.Point(87, 335);
            this.b_cancel_add_motorista.Name = "b_cancel_add_motorista";
            this.b_cancel_add_motorista.Size = new System.Drawing.Size(140, 51);
            this.b_cancel_add_motorista.TabIndex = 11;
            this.b_cancel_add_motorista.Text = "Cancelar";
            this.b_cancel_add_motorista.UseVisualStyleBackColor = true;
            this.b_cancel_add_motorista.Click += new System.EventHandler(this.b_cancel_add_motorista_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label26.Location = new System.Drawing.Point(15, 7);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(151, 22);
            this.label26.TabIndex = 0;
            this.label26.Text = "Novo Motorista";
            // 
            // painel_addencomenda
            // 
            this.painel_addencomenda.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_addencomenda.Controls.Add(this.radioButton2);
            this.painel_addencomenda.Controls.Add(this.radioButton1);
            this.painel_addencomenda.Controls.Add(this.label30);
            this.painel_addencomenda.Controls.Add(this.textBox9);
            this.painel_addencomenda.Controls.Add(this.label29);
            this.painel_addencomenda.Controls.Add(this.b_ok_addencomenda);
            this.painel_addencomenda.Controls.Add(this.b_cancel_add_encomenda);
            this.painel_addencomenda.Controls.Add(this.label12);
            this.painel_addencomenda.Controls.Add(this.textBox1);
            this.painel_addencomenda.Controls.Add(this.label11);
            this.painel_addencomenda.Controls.Add(this.checkedListBox1);
            this.painel_addencomenda.Controls.Add(this.label10);
            this.painel_addencomenda.Controls.Add(this.comboBox2);
            this.painel_addencomenda.Controls.Add(this.label9);
            this.painel_addencomenda.Controls.Add(this.comboBox1);
            this.painel_addencomenda.Controls.Add(this.label8);
            this.painel_addencomenda.Controls.Add(this.label7);
            this.painel_addencomenda.Location = new System.Drawing.Point(184, 20);
            this.painel_addencomenda.Name = "painel_addencomenda";
            this.painel_addencomenda.Size = new System.Drawing.Size(567, 399);
            this.painel_addencomenda.TabIndex = 4;
            this.painel_addencomenda.Visible = false;
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.Location = new System.Drawing.Point(206, 265);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(63, 17);
            this.radioButton2.TabIndex = 17;
            this.radioButton2.TabStop = true;
            this.radioButton2.Text = "MBWay";
            this.radioButton2.UseVisualStyleBackColor = true;
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Location = new System.Drawing.Point(137, 265);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(58, 17);
            this.radioButton1.TabIndex = 16;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "PayPal";
            this.radioButton1.UseVisualStyleBackColor = true;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 10F);
            this.label30.Location = new System.Drawing.Point(46, 266);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 16);
            this.label30.TabIndex = 15;
            this.label30.Text = "Método:";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(138, 222);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(282, 20);
            this.textBox9.TabIndex = 14;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 10F);
            this.label29.Location = new System.Drawing.Point(46, 223);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(38, 16);
            this.label29.TabIndex = 13;
            this.label29.Text = "Obs:";
            // 
            // b_ok_addencomenda
            // 
            this.b_ok_addencomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.b_ok_addencomenda.Location = new System.Drawing.Point(311, 335);
            this.b_ok_addencomenda.Name = "b_ok_addencomenda";
            this.b_ok_addencomenda.Size = new System.Drawing.Size(140, 51);
            this.b_ok_addencomenda.TabIndex = 12;
            this.b_ok_addencomenda.Text = "OK";
            this.b_ok_addencomenda.UseVisualStyleBackColor = true;
            this.b_ok_addencomenda.Click += new System.EventHandler(this.b_ok_addencomenda_Click);
            // 
            // b_cancel_add_encomenda
            // 
            this.b_cancel_add_encomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.b_cancel_add_encomenda.Location = new System.Drawing.Point(87, 335);
            this.b_cancel_add_encomenda.Name = "b_cancel_add_encomenda";
            this.b_cancel_add_encomenda.Size = new System.Drawing.Size(140, 51);
            this.b_cancel_add_encomenda.TabIndex = 11;
            this.b_cancel_add_encomenda.Text = "Cancelar";
            this.b_cancel_add_encomenda.UseVisualStyleBackColor = true;
            this.b_cancel_add_encomenda.Click += new System.EventHandler(this.b_cancel_add_encomenda_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 10F);
            this.label12.Location = new System.Drawing.Point(537, 288);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(16, 16);
            this.label12.TabIndex = 10;
            this.label12.Text = "€";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(466, 285);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(65, 20);
            this.textBox1.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 10F);
            this.label11.Location = new System.Drawing.Point(411, 288);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(49, 16);
            this.label11.TabIndex = 8;
            this.label11.Text = "Preço:";
            // 
            // checkedListBox1
            // 
            this.checkedListBox1.FormattingEnabled = true;
            this.checkedListBox1.Location = new System.Drawing.Point(138, 108);
            this.checkedListBox1.Name = "checkedListBox1";
            this.checkedListBox1.Size = new System.Drawing.Size(201, 94);
            this.checkedListBox1.TabIndex = 7;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 10F);
            this.label10.Location = new System.Drawing.Point(15, 112);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(69, 16);
            this.label10.TabIndex = 6;
            this.label10.Text = "Produtos:";
            // 
            // comboBox2
            // 
            this.comboBox2.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(138, 38);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(282, 21);
            this.comboBox2.TabIndex = 5;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 10F);
            this.label9.Location = new System.Drawing.Point(15, 41);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(116, 16);
            this.label9.TabIndex = 4;
            this.label9.Text = "Estabelecimento:";
            // 
            // comboBox1
            // 
            this.comboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(138, 73);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(282, 21);
            this.comboBox1.TabIndex = 3;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 10F);
            this.label8.Location = new System.Drawing.Point(15, 76);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Cliente:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(15, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(173, 22);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nova Encomenda";
            // 
            // painel_encomendas
            // 
            this.painel_encomendas.BackColor = System.Drawing.SystemColors.ControlLight;
            this.painel_encomendas.Controls.Add(this.tabela_encomendas);
            this.painel_encomendas.Controls.Add(this.label19);
            this.painel_encomendas.Controls.Add(this.elim_encomenda);
            this.painel_encomendas.Controls.Add(this.b_edit_encomenda);
            this.painel_encomendas.Controls.Add(this.b_add_encomenda);
            this.painel_encomendas.Location = new System.Drawing.Point(184, 20);
            this.painel_encomendas.Name = "painel_encomendas";
            this.painel_encomendas.Size = new System.Drawing.Size(567, 399);
            this.painel_encomendas.TabIndex = 5;
            // 
            // tabela_encomendas
            // 
            this.tabela_encomendas.AllowUserToAddRows = false;
            this.tabela_encomendas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.tabela_encomendas.Location = new System.Drawing.Point(0, 26);
            this.tabela_encomendas.Name = "tabela_encomendas";
            this.tabela_encomendas.ReadOnly = true;
            this.tabela_encomendas.RowHeadersVisible = false;
            this.tabela_encomendas.Size = new System.Drawing.Size(567, 313);
            this.tabela_encomendas.TabIndex = 0;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 14F, System.Drawing.FontStyle.Bold);
            this.label19.Location = new System.Drawing.Point(3, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(132, 22);
            this.label19.TabIndex = 4;
            this.label19.Text = "Encomendas";
            // 
            // elim_encomenda
            // 
            this.elim_encomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.elim_encomenda.Location = new System.Drawing.Point(392, 345);
            this.elim_encomenda.Name = "elim_encomenda";
            this.elim_encomenda.Size = new System.Drawing.Size(136, 51);
            this.elim_encomenda.TabIndex = 3;
            this.elim_encomenda.Text = "Eliminar";
            this.elim_encomenda.UseVisualStyleBackColor = true;
            this.elim_encomenda.Click += new System.EventHandler(this.elim_encomenda_Click);
            // 
            // b_edit_encomenda
            // 
            this.b_edit_encomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.b_edit_encomenda.Location = new System.Drawing.Point(218, 345);
            this.b_edit_encomenda.Name = "b_edit_encomenda";
            this.b_edit_encomenda.Size = new System.Drawing.Size(136, 51);
            this.b_edit_encomenda.TabIndex = 2;
            this.b_edit_encomenda.Text = "Editar";
            this.b_edit_encomenda.UseVisualStyleBackColor = true;
            this.b_edit_encomenda.Click += new System.EventHandler(this.b_edit_encomenda_Click);
            // 
            // b_add_encomenda
            // 
            this.b_add_encomenda.Font = new System.Drawing.Font("Arial", 13F);
            this.b_add_encomenda.Location = new System.Drawing.Point(43, 345);
            this.b_add_encomenda.Name = "b_add_encomenda";
            this.b_add_encomenda.Size = new System.Drawing.Size(136, 51);
            this.b_add_encomenda.TabIndex = 1;
            this.b_add_encomenda.Text = "Adicionar";
            this.b_add_encomenda.UseVisualStyleBackColor = true;
            this.b_add_encomenda.Click += new System.EventHandler(this.b_add_encomenda_Click);
            // 
            // exit_button
            // 
            this.exit_button.Font = new System.Drawing.Font("Arial", 14F);
            this.exit_button.ForeColor = System.Drawing.Color.Red;
            this.exit_button.Location = new System.Drawing.Point(3, 368);
            this.exit_button.Name = "exit_button";
            this.exit_button.Size = new System.Drawing.Size(162, 51);
            this.exit_button.TabIndex = 6;
            this.exit_button.Text = "Sair";
            this.exit_button.UseVisualStyleBackColor = true;
            this.exit_button.Click += new System.EventHandler(this.exit_button_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel5.Controls.Add(this.label6);
            this.panel5.Location = new System.Drawing.Point(0, 125);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(165, 30);
            this.panel5.TabIndex = 1;
            // 
            // label6
            // 
            this.label6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Arial", 12F);
            this.label6.Location = new System.Drawing.Point(26, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(0, 18);
            this.label6.TabIndex = 0;
            // 
            // b_lateral_clientes
            // 
            this.b_lateral_clientes.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b_lateral_clientes.Font = new System.Drawing.Font("Arial", 12F);
            this.b_lateral_clientes.Location = new System.Drawing.Point(0, 259);
            this.b_lateral_clientes.Name = "b_lateral_clientes";
            this.b_lateral_clientes.Size = new System.Drawing.Size(165, 43);
            this.b_lateral_clientes.TabIndex = 4;
            this.b_lateral_clientes.Text = "Clientes";
            this.b_lateral_clientes.UseVisualStyleBackColor = false;
            this.b_lateral_clientes.Click += new System.EventHandler(this.b_lateral_clientes_Click);
            // 
            // b_motoristas_lateral
            // 
            this.b_motoristas_lateral.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b_motoristas_lateral.Font = new System.Drawing.Font("Arial", 12F);
            this.b_motoristas_lateral.Location = new System.Drawing.Point(0, 210);
            this.b_motoristas_lateral.Name = "b_motoristas_lateral";
            this.b_motoristas_lateral.Size = new System.Drawing.Size(165, 43);
            this.b_motoristas_lateral.TabIndex = 3;
            this.b_motoristas_lateral.Text = "Motoristas";
            this.b_motoristas_lateral.UseVisualStyleBackColor = false;
            this.b_motoristas_lateral.Click += new System.EventHandler(this.b_motoristas_lateral_Click);
            // 
            // b_encomendas_lateral
            // 
            this.b_encomendas_lateral.BackColor = System.Drawing.SystemColors.ControlLight;
            this.b_encomendas_lateral.Font = new System.Drawing.Font("Arial", 12F);
            this.b_encomendas_lateral.Location = new System.Drawing.Point(0, 161);
            this.b_encomendas_lateral.Name = "b_encomendas_lateral";
            this.b_encomendas_lateral.Size = new System.Drawing.Size(165, 43);
            this.b_encomendas_lateral.TabIndex = 2;
            this.b_encomendas_lateral.UseVisualStyleBackColor = false;
            this.b_encomendas_lateral.Click += new System.EventHandler(this.b_encomendas_lateral_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.PaleTurquoise;
            this.panel2.Controls.Add(this.label3);
            this.panel2.Location = new System.Drawing.Point(0, 20);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(165, 27);
            this.panel2.TabIndex = 0;
            // 
            // label3
            // 
            this.label3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F);
            this.label3.Location = new System.Drawing.Point(40, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 18);
            this.label3.TabIndex = 0;
            this.label3.Text = "Information";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(0, 89);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(165, 30);
            this.panel4.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F);
            this.label5.Location = new System.Drawing.Point(29, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 18);
            this.label5.TabIndex = 0;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel3.Controls.Add(this.label4);
            this.panel3.Location = new System.Drawing.Point(0, 53);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(165, 30);
            this.panel3.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Left | System.Windows.Forms.AnchorStyles.Right)));
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F);
            this.label4.Location = new System.Drawing.Point(49, 6);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 18);
            this.label4.TabIndex = 0;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // Nr_Reg
            // 
            this.Nr_Reg.Name = "Nr_Reg";
            // 
            // MarcaVeiculo
            // 
            this.MarcaVeiculo.Name = "MarcaVeiculo";
            // 
            // Matricula
            // 
            this.Matricula.Name = "Matricula";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(420, 207);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(100, 20);
            this.textBox19.TabIndex = 24;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(23, 210);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(95, 13);
            this.label43.TabIndex = 21;
            this.label43.Text = "Marca do Veículo:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(364, 210);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(55, 13);
            this.label42.TabIndex = 23;
            this.label42.Text = "Matrícula:";
            // 
            // comboBox7
            // 
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Location = new System.Drawing.Point(124, 207);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(186, 21);
            this.comboBox7.TabIndex = 22;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.SystemColors.ControlLight;
            this.panel6.Controls.Add(this.label1);
            this.panel6.Controls.Add(this.label2);
            this.panel6.Location = new System.Drawing.Point(12, 12);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(776, 53);
            this.panel6.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // radioButton5
            // 
            this.radioButton5.AutoSize = true;
            this.radioButton5.Location = new System.Drawing.Point(148, 284);
            this.radioButton5.Name = "radioButton5";
            this.radioButton5.Size = new System.Drawing.Size(52, 17);
            this.radioButton5.TabIndex = 45;
            this.radioButton5.TabStop = true;
            this.radioButton5.Text = "Ativar";
            this.radioButton5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 502);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.Text = "Delivery Management";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel1.ResumeLayout(false);
            this.painel_editencomenda.ResumeLayout(false);
            this.painel_editencomenda.PerformLayout();
            this.painel_clientes.ResumeLayout(false);
            this.painel_clientes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabela_clientes)).EndInit();
            this.painel_edit_cliente.ResumeLayout(false);
            this.painel_edit_cliente.PerformLayout();
            this.painel_add_cliente.ResumeLayout(false);
            this.painel_add_cliente.PerformLayout();
            this.painel_motoristas.ResumeLayout(false);
            this.painel_motoristas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabela_motoristas)).EndInit();
            this.painel_edit_motorista.ResumeLayout(false);
            this.painel_edit_motorista.PerformLayout();
            this.painel_addmotorista.ResumeLayout(false);
            this.painel_addmotorista.PerformLayout();
            this.painel_addencomenda.ResumeLayout(false);
            this.painel_addencomenda.PerformLayout();
            this.painel_encomendas.ResumeLayout(false);
            this.painel_encomendas.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.tabela_encomendas)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button b_encomendas_lateral;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Button b_motoristas_lateral;
        private System.Windows.Forms.Button b_lateral_clientes;
        private System.Windows.Forms.Button exit_button;
        private System.Windows.Forms.Panel painel_encomendas;
        private System.Windows.Forms.Button elim_encomenda;
        private System.Windows.Forms.Button b_edit_encomenda;
        private System.Windows.Forms.Button b_add_encomenda;
        private System.Windows.Forms.DataGridView tabela_encomendas;
        private System.Windows.Forms.Panel painel_addencomenda;
        private System.Windows.Forms.Button b_ok_addencomenda;
        private System.Windows.Forms.Button b_cancel_add_encomenda;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel painel_editencomenda;
        private System.Windows.Forms.Button b_ok_editencomenda;
        private System.Windows.Forms.Button b_cancel_edit_encomenda;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel painel_motoristas;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Button b_elim_motorista;
        private System.Windows.Forms.Button b_edit_motorista;
        private System.Windows.Forms.Button b_add_motorista;
        private System.Windows.Forms.DataGridView tabela_motoristas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nr_Reg;
        private System.Windows.Forms.DataGridViewTextBoxColumn MarcaVeiculo;
        private System.Windows.Forms.DataGridViewTextBoxColumn Matricula;
        private System.Windows.Forms.Panel painel_addmotorista;
        private System.Windows.Forms.Button b_ok_add_motorista;
        private System.Windows.Forms.Button b_cancel_add_motorista;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Panel painel_edit_motorista;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Button b_ok_edit_motorista;
        private System.Windows.Forms.Button b_cancel_edit_motorista;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel painel_clientes;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Button b_elim_cliente;
        private System.Windows.Forms.Button b_edit_cliente;
        private System.Windows.Forms.Button b_add_cliente;
        private System.Windows.Forms.Panel painel_add_cliente;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.Button b_ok_add_cliente;
        private System.Windows.Forms.Button b_cancel_add_cliente;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Panel painel_edit_cliente;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Button b_ok_edit_cliente;
        private System.Windows.Forms.Button b_cancel_edit_cliente;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridView tabela_clientes;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.CheckedListBox checkedListBox2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.RadioButton radioButton4;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.RadioButton radioButton5;
    }
}

